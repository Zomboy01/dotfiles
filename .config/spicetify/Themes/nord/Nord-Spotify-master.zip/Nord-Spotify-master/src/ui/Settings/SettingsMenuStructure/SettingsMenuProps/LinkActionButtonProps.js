export default function getSettingsMenuLinkActionButtonProps() {
    return {
        repositionBanner: {
            name: "How to Reposition Banners?",
            url: "https://github.com/Tetrax-10/Nord-Spotify#how-to-reposition-banner-",
        },
    }
}
